﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class staff : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("addstudent");
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("studentreport");
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        Response.Redirect("attendance.aspx");
    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        Response.Redirect("attreport.aspx");
    }
    protected void Button8_Click(object sender, EventArgs e)
    {
        Response.Redirect("advancedreport.aspx");
    }
    protected void Button9_Click(object sender, EventArgs e)
    {
        Response.Redirect("passwordstaff.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("student.aspx");
    }
}
